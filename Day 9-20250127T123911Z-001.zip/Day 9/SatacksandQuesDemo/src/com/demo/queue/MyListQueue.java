package com.demo.queue;

public class MyListQueue {

}
